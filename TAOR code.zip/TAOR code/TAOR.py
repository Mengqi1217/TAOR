import pandas as pd
import pulp
import PyPDF2
import os
from io import BytesIO
import re

# 1. Read the PDF and split pages by question
def split_question(pdf_file_path):
    questions = []
    now_question = []
    with open(pdf_file_path, 'rb') as file:
        pdf_data = BytesIO(file.read())
        reader = PyPDF2.PdfReader(pdf_data)
        num_pages = len(reader.pages)
        for page_num in range(1, num_pages):
            page = reader.pages[page_num]
            text = page.extract_text()
            pattern = r"Question \d+ continued"
            match = re.search(pattern, text)
            if not match:
                if now_question:
                    questions.append(now_question)
                    now_question = []
            now_question.append(page)
        if now_question:
            questions.append(now_question)
    return questions

# 2. Merge selected question PDF pages into one
def generate_pdf(questions, output_filename):
    writer = PyPDF2.PdfWriter()
    for question in questions:
        for page in question:
            writer.add_page(page)
    with open(output_filename, 'wb') as output_file:
        writer.write(output_file)

# 3. Load the CSV file
df = pd.read_csv("A level question bank - Sheet1 (1).csv")

# 4. Combine 'Type' and 'Type 2' columns
def combine_types(row):
    types = []
    if pd.notnull(row["Type"]):
        types.extend(row["Type"].split("\\"))
    if pd.notnull(row["Type 2"]):
        types.extend(row["Type 2"].split("\\"))
    return types

df["unique_type"] = df.apply(combine_types, axis=1)

# 5. Strip whitespace from 'Paper number'
df["Paper number"] = df["Paper number"].astype(str).str.strip()

# 6. Process each paper (e.g., 8MA0 / 9MA0)
for paper_code in df["Paper number"].unique():
    print(f"Processing: {paper_code}")

    df_subset = df[df["Paper number"] == paper_code].copy()

    # Regenerate 'unique_type' to avoid index mismatch
    df_subset["unique_type"] = df_subset.apply(combine_types, axis=1)

    # Get all unique question types
    question_types = set()
    for types in df_subset["unique_type"]:
        question_types.update(types)
    question_types = list(question_types)

    # Setup optimization model
    prob = pulp.LpProblem(f"Exam_Paper_Optimization_{paper_code}", pulp.LpMinimize)
    x = pulp.LpVariable.dicts("selected", df_subset.index, cat="Binary")
    delta = pulp.LpVariable("delta", lowBound=0)

    Q = 15  # number of questions to select
    T = df_subset['score'].sum() * Q / df_subset.shape[0]  # target total score
    l = 1
    u = 5
    dk = 0.1
    ek = 0.1

    total_score = pulp.lpSum(x[i] * df_subset.loc[i, "score"] for i in df_subset.index)
    prob += delta  # objective: minimize deviation from target score
    prob += pulp.lpSum(x[i] for i in df_subset.index) == Q  # select exactly Q questions

    # Constraint: no more than 'u' questions of each type
    for q_type in question_types:
        type_indices = [i for i in df_subset.index if q_type in df_subset.loc[i, "unique_type"]]
        prob += pulp.lpSum(x[i] for i in type_indices) <= u

    # Constraint: score deviation within dk and ek
    prob += delta >= total_score - T - ek
    prob += delta <= total_score - T + dk

    # Solve the model
    prob.solve(pulp.PULP_CBC_CMD(timeLimit=10))

    if pulp.LpStatus[prob.status] == "Optimal":
        selected_indices = [i for i in df_subset.index if x[i].value() == 1]
        selected_questions = df_subset.loc[selected_indices]

        # Load PDF pages
        files = os.listdir('Topic Past Paper')
        question_set = {}

        for file in files:
            pdf_file_path = f'Topic Past Paper/{file}'
            question_set[file.lower()] = split_question(pdf_file_path)

        result_question = []
        for row in selected_questions[['Year', 'Paper number', 'QN']].values:
            # Extract first number from QN (to avoid issues with formats like '3(ii)')
            match = re.search(r'\d+', row[2])
            if match:
                idx = int(match.group())
            else:
                print(f"Unable to parse QN: {row[2]}, skipped")
                continue  # Skip invalid QN to prevent errors

            for key in question_set:
                clean_key = key.replace(" ", "").lower()
                if str(row[0]) in clean_key and row[1].lower() in clean_key:
                    if 0 <= idx - 1 < len(question_set[key]):  # prevent index out of range
                        result_question.append(question_set[key][idx - 1])
                    else:
                        print(f"QN {row[2]} exceeds page range of file {key}, skipped")
                    break

        # Generate final output PDF file
        output_filename = f"{paper_code}_res.pdf"
        generate_pdf(result_question, output_filename)
        print(f"Generated: {output_filename}")
    else:
        print(f"Optimization failed for {paper_code}")
