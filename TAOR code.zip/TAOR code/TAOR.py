import pandas as pd
import pulp
import PyPDF2
import os
from io import BytesIO
import re

# 1. 读取 PDF 并按题目拆分页面
def split_question(pdf_file_path):
    questions = []
    now_question = []
    with open(pdf_file_path, 'rb') as file:
        pdf_data = BytesIO(file.read())
        reader = PyPDF2.PdfReader(pdf_data)
        num_pages = len(reader.pages)
        for page_num in range(1, num_pages):
            page = reader.pages[page_num]
            text = page.extract_text()
            pattern = r"Question \d+ continued"
            match = re.search(pattern, text)
            if not match:
                if now_question:
                    questions.append(now_question)
                    now_question = []
            now_question.append(page)
        if now_question:
            questions.append(now_question)
    return questions

# 2. 合并选中的题目 PDF 页面
def generate_pdf(questions, output_filename):
    writer = PyPDF2.PdfWriter()
    for question in questions:
        for page in question:
            writer.add_page(page)
    with open(output_filename, 'wb') as output_file:
        writer.write(output_file)

# 3. 读取 CSV 文件
df = pd.read_csv("A level question bank - Sheet1 (1).csv")

# 4. 处理类型列 Type 和 Type 2
def combine_types(row):
    types = []
    if pd.notnull(row["Type"]):
        types.extend(row["Type"].split("\\"))
    if pd.notnull(row["Type 2"]):
        types.extend(row["Type 2"].split("\\"))
    return types

df["unique_type"] = df.apply(combine_types, axis=1)

# 5. 预处理 Paper number 去空格
df["Paper number"] = df["Paper number"].astype(str).str.strip()

# 6. 处理每种试卷（8MA0 / 9MA0）
for paper_code in df["Paper number"].unique():
    print(f"Processing: {paper_code}")

    df_subset = df[df["Paper number"] == paper_code].copy()

    # 重新生成 unique_type（避免 index 错位）
    df_subset["unique_type"] = df_subset.apply(combine_types, axis=1)

    # 获取所有出现过的题目类型
    question_types = set()
    for types in df_subset["unique_type"]:
        question_types.update(types)
    question_types = list(question_types)

    # 设置优化模型
    prob = pulp.LpProblem(f"Exam_Paper_Optimization_{paper_code}", pulp.LpMinimize)
    x = pulp.LpVariable.dicts("selected", df_subset.index, cat="Binary")
    delta = pulp.LpVariable("delta", lowBound=0)

    Q = 15
    T = df_subset['score'].sum() * Q / df_subset.shape[0]  # 目标总分
    l = 1
    u = 5
    dk = 0.1
    ek = 0.1

    total_score = pulp.lpSum(x[i] * df_subset.loc[i, "score"] for i in df_subset.index)
    prob += delta
    prob += pulp.lpSum(x[i] for i in df_subset.index) == Q

    for q_type in question_types:
        type_indices = [i for i in df_subset.index if q_type in df_subset.loc[i, "unique_type"]]
        prob += pulp.lpSum(x[i] for i in type_indices) <= u

    prob += delta >= total_score - T - ek
    prob += delta <= total_score - T + dk

    # 求解
    prob.solve(pulp.PULP_CBC_CMD(timeLimit=10))

    if pulp.LpStatus[prob.status] == "Optimal":
        selected_indices = [i for i in df_subset.index if x[i].value() == 1]
        selected_questions = df_subset.loc[selected_indices]

        # 加载 PDF 页面
        files = os.listdir('Topic Past Paper')
        question_set = {}

        for file in files:
            pdf_file_path = f'Topic Past Paper/{file}'
            question_set[file.lower()] = split_question(pdf_file_path)

        result_question = []
        for row in selected_questions[['Year', 'Paper number', 'QN']].values:
            # 解析 QN，提取第一个数字（防止 '3(ii)' 出错）
            match = re.search(r'\d+', row[2])
            if match:
                idx = int(match.group())
            else:
                print(f"⚠️ 无法解析 QN: {row[2]}，跳过")
                continue  # 跳过这个题目，防止报错

            for key in question_set:
                clean_key = key.replace(" ", "").lower()
                if str(row[0]) in clean_key and row[1].lower() in clean_key:
                    if 0 <= idx - 1 < len(question_set[key]):  # 防止索引超出范围
                        result_question.append(question_set[key][idx - 1])
                    else:
                        print(f"⚠️ QN {row[2]} 超出文件 {key} 页数范围，跳过")
                    break

        # 生成对应的 PDF 文件名
        output_filename = f"{paper_code}_res.pdf"
        generate_pdf(result_question, output_filename)
        print(f"✅ Generated: {output_filename}")
    else:
        print(f"❌ Optimization failed for {paper_code}")
