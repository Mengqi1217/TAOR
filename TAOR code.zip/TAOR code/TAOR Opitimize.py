import pandas as pd
import pulp
import PyPDF2
import os
from io import BytesIO
import re

# 1. Read the PDF and split it into questions by page
def split_question(pdf_file_path):
    questions = []
    now_question = []
    with open(pdf_file_path, 'rb') as file:
        pdf_data = BytesIO(file.read())
        reader = PyPDF2.PdfReader(pdf_data)
        num_pages = len(reader.pages)
        for page_num in range(1, num_pages):
            page = reader.pages[page_num]
            text = page.extract_text()
            pattern = r"Question \d+ continued"
            match = re.search(pattern, text)
            if not match:
                if now_question:
                    questions.append(now_question)
                    now_question = []
            now_question.append(page)
        if now_question:
            questions.append(now_question)
    return questions

# 2. Generate a PDF from selected questions
def generate_pdf(questions, output_filename):
    writer = PyPDF2.PdfWriter()
    for question in questions:
        for page in question:
            writer.add_page(page)
    with open(output_filename, 'wb') as output_file:
        writer.write(output_file)

# 3. Load the CSV file
df = pd.read_csv("A level question bank - Sheet1 (1).csv")

# 4. Process 'Type' and 'Type 2' columns
def combine_types(row):
    types = []
    if pd.notnull(row["Type"]):
        types.extend(row["Type"].split("\\"))
    if pd.notnull(row["Type 2"]):
        types.extend(row["Type 2"].split("\\"))
    return types

df["unique_type"] = df.apply(combine_types, axis=1)
df["Paper number"] = df["Paper number"].astype(str).str.strip()

# Get the latest year
latest_year = df["Year"].max()

# 6. Process each paper (8MA0 / 9MA0)
for paper_code in df["Paper number"].unique():
    print(f"Processing: {paper_code}")

    df_subset = df[df["Paper number"] == paper_code].copy()
    df_subset["unique_type"] = df_subset.apply(combine_types, axis=1)

    question_types = set()
    for types in df_subset["unique_type"]:
        question_types.update(types)
    question_types = list(question_types)

    # Get all available years
    unique_years = df_subset["Year"].unique()

    # Setup the optimization model
    prob = pulp.LpProblem(f"Exam_Paper_Optimization_{paper_code}", pulp.LpMinimize)
    x = pulp.LpVariable.dicts("selected", df_subset.index, cat="Binary")
    delta = pulp.LpVariable("delta", lowBound=0)

    Q = 15  # number of questions
    T = df_subset['score'].sum() * Q / df_subset.shape[0]
    dk = 5
    ek = 5

    # Calculate year difference for each question (prefer recent questions)
    year_diff = {i: latest_year - df_subset.loc[i, "Year"] for i in df_subset.index}

    # Define total_score first
    total_score = pulp.lpSum(x[i] * df_subset.loc[i, "score"] for i in df_subset.index)

    # Objective: minimize delta + total year difference
    prob += delta + pulp.lpSum(x[i] * year_diff[i] for i in df_subset.index)

    # Select exactly 15 questions
    prob += pulp.lpSum(x[i] for i in df_subset.index) == Q

    # Year constraints
    selected_years = pulp.LpVariable.dicts("selected_years", unique_years, cat="Binary")

    # At most 7 questions from each year
    for year in unique_years:
        year_indices = [i for i in df_subset.index if df_subset.loc[i, "Year"] == year]
        prob += pulp.lpSum(x[i] for i in year_indices) <= min(7, len(year_indices))

    # Use at least 3 different years
    for year in unique_years:
        year_indices = [i for i in df_subset.index if df_subset.loc[i, "Year"] == year]
        prob += pulp.lpSum(x[i] for i in year_indices) >= 1 - (1 - selected_years[year]) * len(year_indices)

    prob += pulp.lpSum(selected_years[year] for year in unique_years) >= min(3, len(unique_years))

    # Type constraint: max 5 questions per type
    for q_type in question_types:
        type_indices = [i for i in df_subset.index if q_type in df_subset.loc[i, "unique_type"]]
        prob += pulp.lpSum(x[i] for i in type_indices) <= 5

    # Difficulty balance constraints
    prob += pulp.lpSum(x[i] for i in df_subset.index if df_subset.loc[i, "difficulty"] == "Easy") >= min(3, len(df_subset[df_subset["difficulty"] == "Easy"]))
    prob += pulp.lpSum(x[i] for i in df_subset.index if df_subset.loc[i, "difficulty"] == "Medium") >= min(3, len(df_subset[df_subset["difficulty"] == "Medium"]))
    prob += pulp.lpSum(x[i] for i in df_subset.index if df_subset.loc[i, "difficulty"] == "Hard") >= min(4, len(df_subset[df_subset["difficulty"] == "Hard"]))

    prob += delta >= total_score - T - ek
    prob += delta <= total_score - T + dk

    # Solve the model
    prob.solve(pulp.PULP_CBC_CMD(timeLimit=10))

    if pulp.LpStatus[prob.status] == "Optimal":
        selected_indices = [i for i in df_subset.index if x[i].value() == 1]
        selected_questions = df_subset.loc[selected_indices]

        # Save selected questions to CSV
        csv_filename = f"selected_questions_{paper_code}.csv"
        selected_questions[["Year", "Paper number", "QN", "Type", "score", "difficulty"]].to_csv(csv_filename, index=False)
        print(f"Selection data saved to {csv_filename}")

        # Load PDF pages
        files = os.listdir('Topic Past Paper')
        question_set = {}

        for file in files:
            pdf_file_path = f'Topic Past Paper/{file}'
            question_set[file.lower()] = split_question(pdf_file_path)

        result_question = []
        for row in selected_questions[['Year', 'Paper number', 'QN']].values:
            match = re.search(r'\d+', row[2])
            if match:
                idx = int(match.group())
            else:
                print(f"Unable to resolve QN: {row[2]}, skipped")
                continue

            for key in question_set:
                clean_key = key.replace(" ", "").lower()
                if str(row[0]) in clean_key and row[1].lower() in clean_key:
                    if 0 <= idx - 1 < len(question_set[key]):
                        result_question.append(question_set[key][idx - 1])
                    else:
                        print(f"QN {row[2]} exceeds the page range of file {key}, skipped")
                    break

        # Generate final PDF file
        output_filename = f"{paper_code}_Optimize.pdf"
        generate_pdf(result_question, output_filename)
        print(f"Test paper PDF generation completed: {output_filename}")
    else:
        print(f"Optimization failed for {paper_code}")
